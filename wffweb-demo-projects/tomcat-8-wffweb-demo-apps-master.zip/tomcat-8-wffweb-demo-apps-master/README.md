# tomcat-8-wffweb-demo-apps
wffweb demo projects configured for tomcat-8 application server
