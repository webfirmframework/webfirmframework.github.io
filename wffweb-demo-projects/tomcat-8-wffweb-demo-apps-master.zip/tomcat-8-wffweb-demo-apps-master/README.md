# tomcat-8-wffweb-demo-apps
wffweb demo projects configured for [tomcat-8 application server](http://www.mochahost.com/6128-46.html)

[See how it runs](https://youtu.be/PUkYApKxxew)


##### Similar demo project is available [in this repository](https://github.com/webfirmframework/tomcat-8-wffweb-demo-apps) which deployed at [https://wffweb.herokuapp.com](https://wffweb.herokuapp.com)

###### Anybody can contribute demo wffweb apps to this repository.