package com.wffwebdemo.wffwebdemoproject.page;

public interface Threaded {

    public void startAllThreads();

    public void stopAllThreads();

}
